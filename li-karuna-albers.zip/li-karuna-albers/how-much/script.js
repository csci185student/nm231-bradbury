function toggle(width) {
    document.querySelector('.pink-equal').style.width = width;
}

function toggle(button) {
    if (button.value == "OFF") {
      button.value = "ON";
    } else {
      button.value = "OFF";
    }
  }