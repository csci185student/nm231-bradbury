function toggleBoundaries() {
    document.querySelector('container-left').className = 'click-left';
    document.querySelector('container-right').className = 'click-right';
}